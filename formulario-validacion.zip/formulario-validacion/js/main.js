const users = [
  { username: "neyder.ramirez", password: "123Admin.**" },
  {
    username: "juan.bustamante",
    password: "123Admin.**",
  },
  { username: "kevin.mendoza", password: "123Admin.**" }
];

document.querySelector("#app").innerHTML = `
    <div>
      <form id="loginForm">
        <label for="username">Username</label>
        <input type="text" id="username" name="username">
        <label for="password">password</label>
        <input type="password" id="password" name="password">
        <button id="login">Login</button>
      </form>
    </div>
`; 


const form = document.getElementById("loginForm");

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (!username || !password) {
    alert("Hey no hay username o password");
    return;
  }
  const usersFound = users.find(users => 
  users.username === usernameinput && users.password === passwordinput
    );
  if (usersFound) {
    sessionStorage.setItem("users", userFound.username);
    localStorage.setItem("users", userFound.username);
    alert("¡Bienvenido");
  } else {
    alert("Usuario o contraseña incorrectos");
  }
});
