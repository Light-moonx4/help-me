document.querySelector("#regist").innerHTML = `
    <div>
      <form id="registerForm">
        <label for="username">Username</label>
        <input type="text" id="createusername" name="username">
        <label for="createpassword">password</label>
        <input type="password" id="createpassword" name="password">
        <button id="register">Register</button>
      </form>
    </div>
`;