document.querySelector("#regist").innerHTML = `
    <div>
      <form id="registerForm">
        <label for="username">Username</label>
        <input type="text" id="nuevoUsername" name="username">
        <label for="createpassword">Password</label>
        <input type="password" id="nuevaPassword" name="password">
        <button type="submit" id="register">Register</button>
      </form>
      <button type="submit" id="volver">back</button>
    </div>
`;

const guardarRegistro = (event) => {
  event.preventDefault();

  const nuevoUser = document.getElementById("nuevoUsername").value;
  const nuevaPass = document.getElementById("nuevaPassword").value;

  if (!nuevoUser || !nuevaPass) {
    alert("Por favor completa todos los campos");
    return;
  } 
  const usuariosGuardados = JSON.parse(localStorage.getItem("users")) || [];

  usuariosGuardados.push({ username: nuevoUser, password: nuevaPass });
  
  localStorage.setItem("users", JSON.stringify(usuariosGuardados));

  alert("¡Registro exitoso!");
  window.location.href = "index.html"; 
};
const volver = () => {
  localStorage.setItem("volver", "index.html");
  window.location.href = "index.html";
};
document.getElementById("volver")
.addEventListener("click",volver);

document.getElementById("registerForm").addEventListener("submit", guardarRegistro);